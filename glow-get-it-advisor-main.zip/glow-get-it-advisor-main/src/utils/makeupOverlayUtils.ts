
interface FacialLandmark {
  x: number;
  y: number;
  z: number;
}

interface MakeupRegion {
  center: { x: number; y: number };
  width: number;
  height: number;
  angle: number;
  blendRadius?: number;
}

interface FullFaceLook {
  foundation?: string;
  contour?: string;
  blush?: string;
  eyeshadow?: string;
  lipstick?: string;
  intensity: number;
}

// MediaPipe face landmark indices for different facial features
const LANDMARK_INDICES = {
  lips: {
    outer: [61, 146, 91, 181, 84, 17, 314, 405, 320, 307, 375, 321, 308, 324, 318],
    upper: [61, 84, 17, 314, 405, 320, 307],
    lower: [146, 91, 181, 84, 17, 314, 405, 320, 307, 375, 321, 308, 324, 318]
  },
  leftEye: {
    upper: [159, 158, 157, 173, 133, 155, 154, 153, 145, 144, 163, 7],
    lower: [33, 7, 163, 144, 145, 153, 154, 155, 133, 173, 157, 158, 159, 160, 161, 246],
    center: [468, 469, 470, 471, 472]
  },
  rightEye: {
    upper: [386, 385, 384, 398, 362, 382, 381, 380, 374, 373, 390, 249],
    lower: [263, 249, 390, 373, 374, 380, 381, 382, 362, 398, 384, 385, 386, 387, 388, 466],
    center: [473, 474, 475, 476, 477]
  },
  leftCheek: [116, 117, 118, 119, 120, 121, 126, 142, 36, 205, 206, 207, 213, 192, 147],
  rightCheek: [345, 346, 347, 348, 349, 350, 355, 371, 266, 425, 426, 427, 436, 416, 376],
  forehead: [9, 10, 151, 337, 299, 333, 298, 301, 297, 332, 284, 251, 389, 356, 454, 323, 361, 340],
  nose: [1, 2, 5, 4, 6, 19, 20, 94, 125, 141, 235, 236, 3, 51, 48, 115, 131, 134, 102, 49, 220, 305, 290, 331, 294, 279],
  jawline: [172, 136, 150, 149, 176, 148, 152, 377, 400, 378, 379, 365, 397, 288, 361, 323],
  faceContour: [10, 338, 297, 332, 284, 251, 389, 356, 454, 323, 361, 340, 346, 347, 348, 349, 350, 451, 452, 453, 464, 435, 410, 454]
};

export const getFaceContourRegion = (landmarks: FacialLandmark[], imageWidth: number, imageHeight: number): MakeupRegion => {
  const contourPoints = LANDMARK_INDICES.faceContour.map(index => landmarks[index]);
  
  const minX = Math.min(...contourPoints.map(p => p.x * imageWidth));
  const maxX = Math.max(...contourPoints.map(p => p.x * imageWidth));
  const minY = Math.min(...contourPoints.map(p => p.y * imageHeight));
  const maxY = Math.max(...contourPoints.map(p => p.y * imageHeight));
  
  return {
    center: {
      x: (minX + maxX) / 2,
      y: (minY + maxY) / 2
    },
    width: (maxX - minX) * 1.1,
    height: (maxY - minY) * 1.1,
    angle: 0,
    blendRadius: Math.max(maxX - minX, maxY - minY) * 0.3
  };
};

export const getJawlineRegion = (landmarks: FacialLandmark[], imageWidth: number, imageHeight: number): MakeupRegion => {
  const jawPoints = LANDMARK_INDICES.jawline.map(index => landmarks[index]);
  
  const minX = Math.min(...jawPoints.map(p => p.x * imageWidth));
  const maxX = Math.max(...jawPoints.map(p => p.x * imageWidth));
  const minY = Math.min(...jawPoints.map(p => p.y * imageHeight));
  const maxY = Math.max(...jawPoints.map(p => p.y * imageHeight));
  
  return {
    center: {
      x: (minX + maxX) / 2,
      y: (minY + maxY) / 2
    },
    width: maxX - minX,
    height: (maxY - minY) * 0.8,
    angle: 0,
    blendRadius: (maxX - minX) * 0.2
  };
};

export const getForeheadRegion = (landmarks: FacialLandmark[], imageWidth: number, imageHeight: number): MakeupRegion => {
  const foreheadPoints = LANDMARK_INDICES.forehead.map(index => landmarks[index]);
  
  const minX = Math.min(...foreheadPoints.map(p => p.x * imageWidth));
  const maxX = Math.max(...foreheadPoints.map(p => p.x * imageWidth));
  const minY = Math.min(...foreheadPoints.map(p => p.y * imageHeight));
  const maxY = Math.max(...foreheadPoints.map(p => p.y * imageHeight));
  
  return {
    center: {
      x: (minX + maxX) / 2,
      y: minY - (maxY - minY) * 0.3 // Extend upward for forehead
    },
    width: (maxX - minX) * 1.2,
    height: (maxY - minY) * 1.5,
    angle: 0,
    blendRadius: (maxX - minX) * 0.3
  };
};

export const getLipRegion = (landmarks: FacialLandmark[], imageWidth: number, imageHeight: number): MakeupRegion => {
  const lipPoints = LANDMARK_INDICES.lips.outer.map(index => landmarks[index]);
  
  const minX = Math.min(...lipPoints.map(p => p.x * imageWidth));
  const maxX = Math.max(...lipPoints.map(p => p.x * imageWidth));
  const minY = Math.min(...lipPoints.map(p => p.y * imageHeight));
  const maxY = Math.max(...lipPoints.map(p => p.y * imageHeight));
  
  return {
    center: {
      x: (minX + maxX) / 2,
      y: (minY + maxY) / 2
    },
    width: maxX - minX,
    height: maxY - minY,
    angle: 0,
    blendRadius: Math.min(maxX - minX, maxY - minY) * 0.1
  };
};

export const getEyeRegion = (landmarks: FacialLandmark[], imageWidth: number, imageHeight: number, isLeft: boolean): MakeupRegion => {
  const eyeIndices = isLeft ? LANDMARK_INDICES.leftEye : LANDMARK_INDICES.rightEye;
  const upperPoints = eyeIndices.upper.map(index => landmarks[index]);
  const lowerPoints = eyeIndices.lower.map(index => landmarks[index]);
  const allPoints = [...upperPoints, ...lowerPoints];
  
  const minX = Math.min(...allPoints.map(p => p.x * imageWidth));
  const maxX = Math.max(...allPoints.map(p => p.x * imageWidth));
  const minY = Math.min(...allPoints.map(p => p.y * imageHeight));
  const maxY = Math.max(...allPoints.map(p => p.y * imageHeight));
  
  return {
    center: {
      x: (minX + maxX) / 2,
      y: (minY + maxY) / 2
    },
    width: (maxX - minX) * 1.3,
    height: (maxY - minY) * 1.8,
    angle: 0,
    blendRadius: Math.max(maxX - minX, maxY - minY) * 0.4
  };
};

export const getCheekRegion = (landmarks: FacialLandmark[], imageWidth: number, imageHeight: number, isLeft: boolean): MakeupRegion => {
  const cheekIndices = isLeft ? LANDMARK_INDICES.leftCheek : LANDMARK_INDICES.rightCheek;
  const cheekPoints = cheekIndices.map(index => landmarks[index]);
  
  const minX = Math.min(...cheekPoints.map(p => p.x * imageWidth));
  const maxX = Math.max(...cheekPoints.map(p => p.x * imageWidth));
  const minY = Math.min(...cheekPoints.map(p => p.y * imageHeight));
  const maxY = Math.max(...cheekPoints.map(p => p.y * imageHeight));
  
  return {
    center: {
      x: (minX + maxX) / 2,
      y: (minY + maxY) / 2
    },
    width: (maxX - minX) * 0.9,
    height: (maxY - minY) * 0.9,
    angle: 0,
    blendRadius: Math.max(maxX - minX, maxY - minY) * 0.3
  };
};

export const applyFoundation = (
  ctx: CanvasRenderingContext2D,
  faceRegion: MakeupRegion,
  color: string,
  intensity: number
) => {
  console.log('Applying foundation with color:', color, 'intensity:', intensity);
  ctx.save();
  
  // Create a soft, natural foundation application
  ctx.globalCompositeOperation = 'multiply';
  ctx.globalAlpha = Math.max(0.05, intensity * 0.2 / 100); // Ensure minimum visibility
  
  // Create a large gradient that covers the entire face
  const gradient = ctx.createRadialGradient(
    faceRegion.center.x, faceRegion.center.y, 0,
    faceRegion.center.x, faceRegion.center.y, faceRegion.blendRadius || faceRegion.width
  );
  
  gradient.addColorStop(0, color);
  gradient.addColorStop(0.6, color);
  gradient.addColorStop(1, 'transparent');
  
  ctx.fillStyle = gradient;
  
  // Apply foundation as a large ellipse covering the face
  ctx.beginPath();
  ctx.ellipse(
    faceRegion.center.x,
    faceRegion.center.y,
    faceRegion.width / 2,
    faceRegion.height / 2,
    0, 0, 2 * Math.PI
  );
  ctx.fill();
  
  ctx.restore();
  console.log('Foundation applied');
};

export const applyContour = (
  ctx: CanvasRenderingContext2D,
  jawlineRegion: MakeupRegion,
  foreheadRegion: MakeupRegion,
  color: string,
  intensity: number
) => {
  console.log('Applying contour with color:', color, 'intensity:', intensity);
  ctx.save();
  
  ctx.globalCompositeOperation = 'multiply';
  ctx.globalAlpha = Math.max(0.1, intensity * 0.3 / 100);
  
  // Contour jawline
  const jawGradient = ctx.createRadialGradient(
    jawlineRegion.center.x, jawlineRegion.center.y + jawlineRegion.height * 0.3, 0,
    jawlineRegion.center.x, jawlineRegion.center.y + jawlineRegion.height * 0.3, jawlineRegion.blendRadius || jawlineRegion.width * 0.3
  );
  
  jawGradient.addColorStop(0, color);
  jawGradient.addColorStop(0.7, color);
  jawGradient.addColorStop(1, 'transparent');
  
  ctx.fillStyle = jawGradient;
  ctx.beginPath();
  ctx.ellipse(
    jawlineRegion.center.x,
    jawlineRegion.center.y + jawlineRegion.height * 0.2,
    jawlineRegion.width / 2,
    jawlineRegion.height / 3,
    0, 0, 2 * Math.PI
  );
  ctx.fill();
  
  // Contour forehead sides
  const foreheadGradient = ctx.createRadialGradient(
    foreheadRegion.center.x, foreheadRegion.center.y, 0,
    foreheadRegion.center.x, foreheadRegion.center.y, foreheadRegion.blendRadius || foreheadRegion.width * 0.2
  );
  
  foreheadGradient.addColorStop(0, 'transparent');
  foreheadGradient.addColorStop(0.6, color);
  foreheadGradient.addColorStop(1, 'transparent');
  
  ctx.fillStyle = foreheadGradient;
  
  // Left forehead contour
  ctx.beginPath();
  ctx.ellipse(
    foreheadRegion.center.x - foreheadRegion.width * 0.3,
    foreheadRegion.center.y,
    foreheadRegion.width * 0.15,
    foreheadRegion.height * 0.3,
    0, 0, 2 * Math.PI
  );
  ctx.fill();
  
  // Right forehead contour
  ctx.beginPath();
  ctx.ellipse(
    foreheadRegion.center.x + foreheadRegion.width * 0.3,
    foreheadRegion.center.y,
    foreheadRegion.width * 0.15,
    foreheadRegion.height * 0.3,
    0, 0, 2 * Math.PI
  );
  ctx.fill();
  
  ctx.restore();
  console.log('Contour applied');
};

export const applyMakeupToRegion = (
  ctx: CanvasRenderingContext2D,
  region: MakeupRegion,
  color: string,
  intensity: number,
  blendMode: GlobalCompositeOperation = 'multiply'
) => {
  console.log('Applying makeup to region with color:', color, 'intensity:', intensity);
  ctx.save();
  
  // Set blend mode and opacity
  ctx.globalCompositeOperation = blendMode;
  ctx.globalAlpha = Math.max(0.1, intensity / 100);
  
  // Create gradient for more realistic application
  const gradient = ctx.createRadialGradient(
    region.center.x, region.center.y, 0,
    region.center.x, region.center.y, region.blendRadius || Math.max(region.width, region.height) / 2
  );
  
  gradient.addColorStop(0, color);
  gradient.addColorStop(0.7, color);
  gradient.addColorStop(1, 'transparent');
  
  ctx.fillStyle = gradient;
  
  // Apply rotation if needed
  if (region.angle !== 0) {
    ctx.translate(region.center.x, region.center.y);
    ctx.rotate(region.angle);
    ctx.translate(-region.center.x, -region.center.y);
  }
  
  // Draw the makeup
  ctx.beginPath();
  ctx.ellipse(
    region.center.x,
    region.center.y,
    region.width / 2,
    region.height / 2,
    0, 0, 2 * Math.PI
  );
  ctx.fill();
  
  ctx.restore();
  console.log('Makeup applied to region');
};

export const applyFullFaceLook = (
  ctx: CanvasRenderingContext2D,
  landmarks: FacialLandmark[],
  width: number,
  height: number,
  look: FullFaceLook
) => {
  console.log('Starting full face look application:', look);
  
  if (!landmarks || landmarks.length === 0) {
    console.error('No landmarks available for full face look');
    return;
  }

  try {
    // Get all facial regions
    const faceContour = getFaceContourRegion(landmarks, width, height);
    const jawline = getJawlineRegion(landmarks, width, height);
    const forehead = getForeheadRegion(landmarks, width, height);
    const leftCheek = getCheekRegion(landmarks, width, height, true);
    const rightCheek = getCheekRegion(landmarks, width, height, false);
    const leftEye = getEyeRegion(landmarks, width, height, true);
    const rightEye = getEyeRegion(landmarks, width, height, false);
    const lips = getLipRegion(landmarks, width, height);
    
    console.log('Facial regions calculated successfully');
    
    // Apply makeup in the correct order for realistic layering
    
    // 1. Foundation (base layer)
    if (look.foundation) {
      console.log('Applying foundation:', look.foundation);
      applyFoundation(ctx, faceContour, look.foundation, look.intensity);
    }
    
    // 2. Contour (adds dimension)
    if (look.contour) {
      console.log('Applying contour:', look.contour);
      applyContour(ctx, jawline, forehead, look.contour, look.intensity);
    }
    
    // 3. Blush (adds color to cheeks)
    if (look.blush) {
      console.log('Applying blush:', look.blush);
      applyMakeupToRegion(ctx, leftCheek, look.blush, look.intensity * 0.8, 'multiply');
      applyMakeupToRegion(ctx, rightCheek, look.blush, look.intensity * 0.8, 'multiply');
    }
    
    // 4. Eyeshadow (eye enhancement)
    if (look.eyeshadow) {
      console.log('Applying eyeshadow:', look.eyeshadow);
      applyMakeupToRegion(ctx, leftEye, look.eyeshadow, look.intensity * 0.7, 'multiply');
      applyMakeupToRegion(ctx, rightEye, look.eyeshadow, look.intensity * 0.7, 'multiply');
    }
    
    // 5. Lipstick (final touch)
    if (look.lipstick) {
      console.log('Applying lipstick:', look.lipstick);
      applyMakeupToRegion(ctx, lips, look.lipstick, look.intensity, 'multiply');
    }
    
    console.log('Full face look application completed successfully');
  } catch (error) {
    console.error('Error applying full face look:', error);
  }
};

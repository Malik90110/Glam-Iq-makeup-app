
export interface Product {
  id: string;
  brand: string;
  name: string;
  shade: string;
  category: string;
  price: string;
  description: string;
}

export interface SavedLook {
  id: string;
  name: string;
  date: string;
  products: Product[];
}
